package com.forwardslash.fs;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
