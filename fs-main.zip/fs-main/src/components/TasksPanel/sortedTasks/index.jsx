import BY_DEFAULT from "./ByDefault";
import BY_DUE from "./ByDue";
import BY_STATUS from "./ByStatus";
import BY_PRIORITY from "./ByPriority";
import BY_TAG from "./ByTag";

export default {
  BY_DEFAULT,
  BY_DUE,
  BY_STATUS,
  BY_PRIORITY,
  BY_TAG,
};
