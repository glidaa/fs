export const SIGNIN = '/s';
export const SIGNUP = '/l';